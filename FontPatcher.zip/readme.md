
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 7deaff60d02ad26c38f4f8cc714300c08f598b1e
        Author: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
        Date:   Wed Jul 26 14:10:33 2023 +0000
        
            docs: update .all-contributorsrc
